export TF_VAR_client_id="1a1d670b-b238-44e2-a15b-49f1d0b36b53"
export TF_VAR_client_secret="K1j8Q~c2jkceoSOn3x.hghz15D4HYy_G22UW.bhD"
export TF_VAR_tenant_id="ddb9a70f-27b4-400c-925a-b328484f6037"
export TF_VAR_service_principal_object_id="90319793-c5d2-4fbf-a6f0-a2a93445ba06"
export TF_VAR_subscription_id=$(az account show --query id --output tsv)