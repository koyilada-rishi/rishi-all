
alias t=terraform
alias tin="terraform init"
alias tv="terraform validate"
alias tpl="terraform plan"
alias tap="terraform apply"
alias tds="terraform destroy"
# export subscription_id="8ff3267d-94de-4a41-9e4e-c06fd3d5fbfa"
alias atap="terraform apply -auto-approve"
alias adap="terraform destroy -auto-approve"
alias trf="rm -rf .terraform*  terraform.tfstate*"
